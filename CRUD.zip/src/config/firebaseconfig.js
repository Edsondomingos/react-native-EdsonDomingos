// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"

const firebaseConfig = {
  // COLAR AQUI O CÓDIGO DE ACESSO AO FIREBASE
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);