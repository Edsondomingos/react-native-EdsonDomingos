import { useState } from 'react'
import { Text, View, TextInput, Button} from 'react-native'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "firebase/auth"
import { authentication } from './src/config/firebaseconfig'

export default () => {
    
    const [email, setEmail] = useState('')
    const [senha, setSenha] = useState('')

    function autenticar(){
        signInWithEmailAndPassword(authentication, email, senha)
        .then((userCredential) => {
            // Signed in
            const user = userCredential.user;
            alert("Autenticado");
            setEmail("");
            setSenha("");
        })
        .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            alert(errorMessage);
        });
    }

    function cadastrar(){
        createUserWithEmailAndPassword(authentication, email, senha)
            .then((userCredential) => {
                // Signed in
                const user = userCredential.user;
                alert("Cadastrado");
                setEmail("");
                setSenha("");
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                alert(errorMessage);
                // ..
            });
    }   

    function logout(){
        signOut(authentication).then(() => {
            alert("Desconectado");
          }).catch((error) => {
            alert(error);
          });
    }


    return (
        <View>
            <Text>Autenticação</Text>
            <TextInput value={email} placeholder='E-mail' onChangeText={setEmail} />
            <TextInput value={senha} placeholder='Senha' onChangeText={setSenha}/>
            <Button title='Cadastrar' onPress={cadastrar} />
            <Button title='Autenticar' onPress={autenticar} />
            <Button title='Logout' onPress={logout} />
            <Button title='Verificar Usuário Autenticado' onPress={() => {
                if(authentication.currentUser){
                    alert(authentication.currentUser.email)
                }else{
                    alert("Não existe usuário autenticado")
                }
                
            }} />
        </View>
    )
}